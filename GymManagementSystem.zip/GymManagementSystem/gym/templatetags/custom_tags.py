from django import template
from gym.models import *
register = template.Library()

